//
//  ViewController.m
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "ViewController.h"
#import "ZJFirstPushViewController.h"
#import "ZJThreeModalViewController.h"

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSArray *datas;
@end

@implementation ViewController

- (NSArray *)datas
{
    if (!_datas) {
     
        _datas = [NSArray array];
    }
    return _datas;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    _datas = @[@"转场Push", @"转场Modal"];

}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *ID = @"IDCELL";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        cell.textLabel.text = _datas[indexPath.row];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        
        ZJFirstPushViewController *firstVc = [[ZJFirstPushViewController alloc] init];
        [self.navigationController pushViewController:firstVc animated:YES];
    } else
    {
        ZJThreeModalViewController *threeVc = [ZJThreeModalViewController new];
        [self.navigationController pushViewController:threeVc animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
