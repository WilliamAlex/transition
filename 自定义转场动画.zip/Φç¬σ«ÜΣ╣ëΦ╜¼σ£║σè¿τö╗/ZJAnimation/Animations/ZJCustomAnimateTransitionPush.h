//
//  ZJCustomAnimateTransitionPush.h
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/*
 需要注意的几点:
 1, 如果需要实现在push的时候实现转场动画, 必须要准守UINavigationControllerDelegate协议
 原因: 在UINavigationControllerDelegate协议中提供的方法:
 1.1, 这个方法主要是用来自定义转场动画的(在该方法中只需要返回一个遵守了UIViewControllerInteractiveTransitioning协议的对象即可)
 - (nullable id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
 animationControllerForOperation:(UINavigationControllerOperation)operation
 fromViewController:(UIViewController *)fromVC
 toViewController:(UIViewController *)toVC  NS_AVAILABLE_IOS(7_0);
 
 1.2, 该方法主要是为该动画添加用户交互
 - (nullable id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
 interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>) animationController NS_AVAILABLE_IOS(7_0);
 
 具体思路:
 1, 创建两个继承自NSObject, 并且遵守了UIViewControllerInteractiveTransitioning协议的两个类对象(分别是用于push类和pop类)
 2, 重写UIViewControllerAnimatedTransitioning协议中的几个代理方法
 2.1, 返回动画的执行时间
 - (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext;
 2.2, 将动画的代码写到里面即可
 - (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext;
 
 注意点: UIViewControllerContextTransitioning协议是UIKit框架的, 需要导入UIKit框架
 
 */

@interface ZJCustomAnimateTransitionPush : NSObject<UIViewControllerAnimatedTransitioning>

@end

/*
 使用push转场动画的步骤:
 
 1, 使用转场动画需要来源控制器以及目标控制器
 2, 两个控制器需要遵守UINavigationControllerDelegate协议, 并且实现协议中的方法, 在协议方法中返回一个遵守了UIViewControllerInteractiveTransitioning协议的对象(注意, 这个对象是继承自NSObject的对象: 在demo就是:ZJCustomAnimateTransitionPush和ZJCustomAnimateTransitionPop两个对象)
 3, 一定要在ViewWillAppear中设置当前控制器为UINavigationControllerDelegate的代理
 4, 实现UINavigationControllerDelegate中的代理方法, 返回自定义转场的对象.
 比如:
 - (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC
 {
 
 if (operation == UINavigationControllerOperationPush) {
 
 ZJCustomAnimateTransitionPush *push = [ZJCustomAnimateTransitionPush new];
 return push;
 }else
 {
 return nil;
 }
 }
 5, 在目标控制器中同样需要遵守UINavigationControllerDelegate协议, 并在ViewWillAppear中设置代理
 6, 设置代理后在实现代理中的方法:
 比如:
 //为这个动画添加用户交互
 - (id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
 interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>) animationController {
 return self.interactiveTransition;
 }
 
 //用来自定义转场动画
 - (id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
 animationControllerForOperation:(UINavigationControllerOperation)operation
 fromViewController:(UIViewController *)fromVC
 toViewController:(UIViewController *)toVC{
 if (operation == UINavigationControllerOperationPop) {
 ZJCustomAnimateTransitionPop   *pingInvert = [ZJCustomAnimateTransitionPop new];
 return pingInvert;
 }else{
 return nil;
 }
 }

 特别注意的: 在两个push和pop类对象中代码机会是一致的, 只是跳转的控制器(即来源控制器和目标控制器)不一样.
 
 // 动画的执行时间
 - (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext;
 
 // 将动画的代码写到该方法中
 -(void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext;
 
 // 转场动画完毕之后需要将他们全部移除掉
 - (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag;
 */






































