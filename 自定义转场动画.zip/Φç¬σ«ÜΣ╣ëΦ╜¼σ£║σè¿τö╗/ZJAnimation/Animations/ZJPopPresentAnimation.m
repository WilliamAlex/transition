//
//  ZJPopPresentAnimation.m
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "ZJPopPresentAnimation.h"
#import "ZJThreeModalViewController.h"
#import "ZJFourModalViewController.h"


@interface ZJPopPresentAnimation()

// transitionContext
@property (nonatomic, strong) id<UIViewControllerContextTransitioning>transitionContext;
@end
@implementation ZJPopPresentAnimation

// 动画的执行时间
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext
{
    return 0.7;
}

// 转场动画
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext
{
    
    self.transitionContext = transitionContext;
    
    // 获取来源控制器和目标控制器
    ZJThreeModalViewController *fromVc = (ZJThreeModalViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    ZJFourModalViewController *toVc = (ZJFourModalViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    toVc.view.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 300);
    
    // 将视图添加到容器中
    [[transitionContext containerView] addSubview:toVc.view];
    
    /**********************************编码你想要的动画****************************************/

    CATransform3D t1 = CATransform3DIdentity;
    t1.m34 = 1.0/-900;
    t1 = CATransform3DScale(t1, 0.95, 0.95, 1);
    t1 = CATransform3DRotate(t1, 15.0 * M_PI/180.0, 1, 0, 0);
    
    CATransform3D t2 = CATransform3DIdentity;
    t2.m34 = 1.0/-900;
    //向上移
    t2 = CATransform3DTranslate(t2, 0, fromVc.view.frame.size.height * (-0.08), 0);
    //第二次缩小
    t2 = CATransform3DScale(t2, 0.8, 0.8, 1);
    
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        [fromVc.view.layer setTransform:t1];
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            fromVc.view.alpha = 0.5;
            
            CGRect rect    = toVc.view.frame;
            rect.origin.y -= rect.size.height;
            toVc.view.frame = rect;
            
            [fromVc.view.layer setTransform:t2];
            
        } completion:^(BOOL finished) {
            [transitionContext completeTransition:YES];
        }];
    }];

    /**********************************上述是您编码的动画****************************************/
}

@end
