//
//  ZJFourModalViewController.m
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "ZJFourModalViewController.h"

@interface ZJFourModalViewController ()

@end

@implementation ZJFourModalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.layer.shadowColor = [UIColor blackColor].CGColor;
    self.view.layer.shadowOffset = CGSizeMake(0.5, 0.5);
    self.view.layer.shadowOpacity = 0.8;
    self.view.layer.shadowRadius = 5;
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton * closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(15, 0, 50, 40);
    [closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [closeBtn setTitleColor:[UIColor colorWithRed:217/255.0 green:110/255.0 blue:90/255.0 alpha:1] forState:UIControlStateNormal];
    [closeBtn addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:closeBtn];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(0, 50, [UIScreen mainScreen].bounds.size.width, 100);
    label.text = @"主要目的就是知道自定义转场的具体步骤是什么, 至于动画效果可以自己定义";
    label.numberOfLines = 0;
    label.textColor = [UIColor colorWithRed:217/255.0 green:110/255.0 blue:90/255.0 alpha:0.6];
    [self.view addSubview:label];
    
}

- (void)close {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
