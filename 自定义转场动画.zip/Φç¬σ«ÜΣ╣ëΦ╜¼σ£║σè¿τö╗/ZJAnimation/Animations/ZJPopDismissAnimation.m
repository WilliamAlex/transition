//
//  ZJPopDismissAnimation.m
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import "ZJPopDismissAnimation.h"
#import "ZJThreeModalViewController.h"
#import "ZJFourModalViewController.h"


@implementation ZJPopDismissAnimation

// 动画的执行时间
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext
{
    return 0.7;
}

// 转场动画
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext
{
    
    // 获取来源控制器和目标控制器
    ZJFourModalViewController *fromVc = (ZJFourModalViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    ZJThreeModalViewController *toVc = (ZJThreeModalViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    /**********************************编码你想要的动画****************************************/
    CATransform3D trans = CATransform3DIdentity;
    trans.m34 = 1.0/ -900;
    trans = CATransform3DScale(trans, 0.95, 0.95, 1);
    trans = CATransform3DRotate(trans, 15.0 * M_PI/180.0, 1, 0, 0);
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        CGRect rect    = fromVc.view.frame;
        rect.origin.y += rect.size.height;
        fromVc.view.frame = rect;
        
        [toVc.view.layer setTransform:trans];
        
    } completion:^(BOOL finished) {
        
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            toVc.view.alpha = 1;
            [toVc.view.layer setTransform:CATransform3DIdentity];
            
        } completion:^(BOOL finished) {
            [transitionContext completeTransition:YES];
        }];
    }];
    
    /**********************************上述是您编码的动画****************************************/
}
@end
