//
//  ZJPopDismissAnimation.h
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ZJPopDismissAnimation : NSObject<UIViewControllerAnimatedTransitioning>


@end
