//
//  ZJThreeModalViewController.m
//  ZJAnimation
//
//  Created by Alex on 2017/2/24.
//  Copyright © 2017年 ShenZhenQinJin. All rights reserved.
//

/*
 Modal转场的基本步骤:
 1, 同样是需要来源控制器和目标控制器
 2, 在来源控制器中遵守UIViewControllerTransitioningDelegate协议, 实现协议中的代理方法
 比如:
 // 代理方法1: 需要返回的是你需要present的类对象
 (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source;
 
 // 代理方法2: 需要dismiss的类对象
 - (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed;
 3, 在目标控制器中正常dismiss即可
 
 4, 创建两个继承自NSObject的类对象, 在两个类中编码你需要的转场动画即可
 
 5, 在类对象中遵守UIViewControllerAnimatedTransitioning协议,实现的方法和之前push对象类中实现的方法步骤是一样的
 
 */

#import "ZJThreeModalViewController.h"
#import "ZJPopPresentAnimation.h"
#import "ZJPopDismissAnimation.h"
#import "ZJFourModalViewController.h"

@interface ZJThreeModalViewController ()<UIViewControllerTransitioningDelegate>

@end

@implementation ZJThreeModalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"自定义Model转场动画";
    self.view.backgroundColor = [UIColor colorWithRed:217/255.0 green:110/255.0 blue:90/255.0 alpha:1];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{

    // 设置代理
    ZJFourModalViewController *fourVc = [[ZJFourModalViewController alloc] init];
    fourVc.transitioningDelegate = self;
    fourVc.modalPresentationStyle = UIModalPresentationCustom;
    [self presentViewController:fourVc animated:YES completion:nil];
}

// present控制器的转场动画
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source
{
    return [[ZJPopPresentAnimation alloc] init];
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed
{
    return [ZJPopDismissAnimation new];
}

@end
